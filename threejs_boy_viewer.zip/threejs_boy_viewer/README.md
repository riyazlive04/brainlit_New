# Three.js Boy Character Viewer

## Files
- `index.html`
- `main.js`
- `boy.glb` — add your actual 3D character file using this exact filename.

## Run locally

Opening `index.html` directly may block model loading. Run a local server:

### Python
```bash
python -m http.server 8000
```

Then open:

```text
http://localhost:8000/threejs_boy_viewer/
```

## Important
The turnaround PNG is a 2D modeling reference. It cannot itself behave as a real 3D character.
A rigged or static `boy.glb` must first be created in Blender, Maya, Cinema 4D, Character Creator,
or through a dedicated image-to-3D service.

The supplied Three.js code automatically:
- loads `boy.glb`
- centres and scales the model
- enables rotation and zoom
- adds lights and shadows
- plays the first embedded animation, when available
